/**
 * products.js
 *
 * The store's products are defined as an Array of product Objects.
 * Each product Object includes the following properties:
 *
 *  - id: String, a unique product identifier (e.g., "P1", "P2")
 *  - title: String, a short name for the product (e.g., "Gingerbread Cookie")
 *  - description: String, a description of the product
 *  - price: Number, the unit price of the item in whole cents (e.g., 100 = $1.00, 5379 = $53.79)
 *  - discontinued: Boolean, whether or not the product has been discontinued
 *  - categories: Array, the category id or ids to which this product belongs (e.g., ["c1"] or ["c1", "c2"])
 */

window.products = [
  /*
    {
      id: "P1",
      title: "Title 1",
      description: "Description 1...",
      price: 199,
      discontinued: false,
      categories: ["c1"]
    },
  */
  {
    id: "11725",
    title: "Minimalist Chronograph Black Stainless Steel Watch",
    description:
      "Case Size: 42 mm , Movement: Quartz Chronograph , Platform: MINIMALIST CHRONO Strap Material: At Least 50% Recycled Stainless Steel Case , Water Resistance: 5 ATM",
    price: 26000,
    discontinued: false,
    categories: ["WTC-MEN"]
  },

  {
    id: "19200",
    title: "Northwall (Leadwood/Rock Gray)",
    description:
      "Case: 45mm diameter, made of leadwood, Case Thickness: 11mm , Crystal: Hardened mineral glass , Dial: Rock gray , Movement: Quartz Seiko VD53 Bracelet: 22mm width, adjustable length, made of leadwood , Weight: 64.5g / 2.3 oz. , Water Resistance: Splash-proof ",
    price: 33500,
    discontinued: false,
    categories: ["WTC-MEN", "WTC-WOMEN", "WTC-UNISEX"]
  },

  {
    id: "18945",
    title: "Diesel Mr. Daddy Chronograph Gunmetal-Tone Stainless Steel Watch",
    description:
      "Case Size: 57 mm , Movement: Chronograph , Platform: MR. DADDY , Strap Material: Stainless Steel, Case Water Resistance: 3 ATM , Case Material: Stainless Steel",
    price: 33500,
    discontinued: false,
    categories: ["WTC-MEN"]
  },

  {
    id: "19605",
    title: "G-Shock by Casio Men's Analog Watch Gray Rock Python",
    description:
      "Item Shape	Round , Display Type	Analog-Digital , Case material	Glass , Band Colour	Gray , Special features	Notifications, Phone Call, Heart Rate Monitor , Item weight	227 grams , Movement	Automatic",
    price: 200000,
    discontinued: false,
    categories: ["WTC-MEN"]
  },

  {
    id: "56892",
    title: "EMPORIO ARMANI Automatic Stainless Steel Watch",
    description:
      "Dial: Green , Case size: 42MM ,Case material: Stainless Steel ,Plating: Silver , Strap/Bracelet: Stainless Steel ,ATM: 10 ATM",
    price: 65000,
    discontinued: false,
    categories: ["WTC-MEN"]
  },

  {
    id: "25896",
    title: "Privateer Sport Mechanical Brown Leather Watch",
    description:
      "Case Size: 45 mm , Movement: Mechanical Automatic , Platform: PRIVATEER SPORT , Strap Material: Leather , Case Water Resistance: 5 ATM ,Case Material: Stainless Steel",
    price: 16000,
    discontinued: false,
    categories: ["WTC-MEN"]
  },

  {
    id: "25717",
    title: "Swaroski Eternal watch",
    description:
      "Colour:  Rose gold tone , Case size: 30 mm , Watch strap length: 16.5 cm , Material:  Rose gold-tone plated, Crystals , Collection:  Eternal , Strap material:  Metal , Made in:  Switzerland , Mechanism:  Quartz",
    price: 35000,
    discontinued: false,
    categories: ["WTC-WOMEN"]
  },

  {
    id: "96453",
    title: "Jacqueline Sun Moon Multifunction Green Leather Watch",
    description:
      "Case Size: 36 mm , Movement: Multifunction , Platform: JACQUELINE , Strap Material: Leather , Case Water Resistance: 3 ATM , Case Material: Stainless Steel",
    price: 20000,
    discontinued: false,
    categories: ["WTC-WOMEN"]
  },

  {
    id: "82548",
    title: "EMPORIO ARMANI Two-Hand Black Leather Watch",
    description:
      "Composition 84% Stainless Steel 10% Leather 5% Crystal 1% Plastic , Movement: Quartz/2 Hand , Dial: Black , Case size: 30MM , Case material: Stainless Steel , Plating: Rose Gold , Strap/Bracelet: Black Leather , ATM: 3 ATM",
    price: 47500,
    discontinued: false,
    categories: ["WTC-WOMEN"]
  },

  {
    id: "56236",
    title: "EMPORIO ARMANI Two-Hand Rose Gold Stainless Steel Watch",
    description:
      "Composition 66% Stainless Steel 30% Leather 3% Crystal 1% Plastic , Movement: Quartz/2 Hand , Dial: Burgundy , Case size: 30MM , Case material: Stainless Steel , Plating: Rose Gold , Strap/Bracelet: Stainless Steel , ATM: 3 ATM",
    price: 54500,
    discontinued: false,
    categories: ["WTC-WOMEN"]
  },

  {
    id: "35741",
    title: "Tillie Mini Three-Hand Stainless Steel Watch",
    description:
      "Case Size: 26 mm , Movement: Quartz , Platform: TILLIE MINI , Strap Material: Stainless Steel , Case Water Resistance: 5 ATM , Case Material: Stainless Steel",
    price: 13500,
    discontinued: false,
    categories: ["WTC-WOMEN"]
  },

  {
    id: "16655",
    title: "Rye Automatic Rose Gold-Tone Stainless Steel Watch",
    description:
      "Case Size: 36 mm , Movement: Automatic , Platform: RYE , Strap Material: Stainless Steel , Case Water Resistance: 5 ATM , Case Material: Stainless Steel",
    price: 222000,
    discontinued: false,
    categories: ["WTC-WOMEN"]
  },

  {
    id: "11456",
    title: "SKAGEN Women's Signatur Quartz Analog Stainless Steel and Leather Watch",
    description:
      "Item Shape	Round , Dial window material type	Crystal , Display Type	Analog , Clasp Type	Tang Buckle , Case material	Stainless Steel , Case diameter	38 millimeters , Case Thickness	7 millimeters , Band Material	Leather , Band size	Womens Standard , Band width	20 millimeters",
    price: 17500,
    discontinued: false,
    categories: ["WTC-WOMEN"]
  },

  {
    id: "52525",
    title: "Twist Mesh 34mm Watch",
    description:
      "Stainless steel case and mesh bracelet , Sliding buckle clasp , 2 hand design , Crystal embellishment , Quartz movement , 34mm case size, 16mm lug width , Water resistant 3 bar",
    price: 19000,
    discontinued: false,
    categories: ["WTC-WOMEN"]
  },

  {
    id: "89652",
    title: "Garmin Venu SQ",
    description:
      "Weight	38g , Wrist strap material Silicone , Face material Mineral crystal glass , IPX rating IP X8 , Dimensions	4 x 4 x 1.2cm , Daily alarms	1 , Snooze	No , Countdown timer	Yes , Stopwatch	Yes , Replaceable batteries	No , Water-resistant	50m",
    price: 19500,
    discontinued: false,
    categories: ["WTC-UNISEX"]
  },

  {
    id: "22564",
    title: "Fossil Gen 6 42mm",
    description:
      "Screen Size	1.28 Inches Special Feature	Activity Tracker, Distance Tracker, Always On Display, GPS, Heart Rate Monitor, Music Player, Notifications, Pedometer, Phone Call, Sleep Monitor,Text Messaging, Oxymeter (SpO2), Time Display, Contactless PaymentsActivity Tracker, Distance Tracker, Always On Display, GPS, Heart Rate Monitor, Music Player, Notifications, Pedometer, Phone Call, Sleep Monitor,Text Messaging",
    price: 22500,
    discontinued: false,
    categories: ["WTC-UNISEX"]
  },

  {
    id: "01161",
    title: "Waterbury Traditional GMT 39mm Leather Strap Watch",
    description:
      "Case Width: 39 mm , Case Material: Stainless Steel , Band Color: Brown , Buckle/Clasp: Buckle , Case Color: Stainless Steel , Case Finish: Brushed/Polished , Case Shape: Round , Case Size: Full Size , Crystal/Lens: Mineral Glass",
    price: 20000,
    discontinued: false,
    categories: ["WTC-UNISEX"]
  },

  {
    id: "32078",
    title: "Holzkern Sears",
    description:
      "Case: 40mm diameter, made of wenge wood , Dial: Anthracite , Movement: Quartz movement by Citizen , Band: 20mm width, adjustable length, made of wenge wood , Luminescent hands (easily tell the time, even in the dark)",
    price: 26000,
    discontinued: false,
    categories: ["WTC-UNISEX"]
  },

  {
    id: "95684",
    title: "Guess Brown Leather Multifunction Watch",
    description: " Case diameter in mm: 46 , Water resistant up to 50 m/ 160 ft",
    price: 200000,
    discontinued: false,
    categories: ["WTC-UNISEX"]
  },

  {
    id: "74893",
    title: "Armani Three-Hand Blue Steel Watch",
    description:
      "Case Size: 42 mm , Movement: Three Hand , Platform: N/A , Strap Material: Stainless Steel , Case Water Resistance: 5 ATM , Case Material: Stainless Steel",
    price: 32000,
    discontinued: false,
    categories: ["WTC-UNISEX"]
  },

  {
    id: "00554",
    title: "Apple Watch Starlight Aluminium Case with Sport Loop",
    description:
      "45mm or 41mm case sizes , 50m water resistant , Swimproof , Certified IP6X dust resistant , Always-On Retina display , Up to 1,000 nits brightness , Blood Oxygen app2 , ECG app , Cellular available , Supports Family Setup , Connect family members who don’t have an iPhone",
    price: 60000,
    discontinued: false,
    categories: ["WTC-MEN", "WTC-WOMEN", "WTC-UNISEX"]
  },

  {
    id: "56741",
    title: "Galaxy Watch 5",
    description: "Silver Galaxy Watch5 44mm , White Sport Band and customize yourself",
    price: 52500,
    discontinued: false,
    categories: ["WTC-MEN", "WTC-WOMEN", "WTC-UNISEX"]
  }
];
